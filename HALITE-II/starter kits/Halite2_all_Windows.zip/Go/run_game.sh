#!/bin/sh

go build MyBot.go
./halite -d "240 160" "./MyBot" "./Mybot"
