#!/bin/sh

./halite -d "240 160" "java -jar build/libs/MyBot.jar" "java -jar build/libs/MyBot.jar"