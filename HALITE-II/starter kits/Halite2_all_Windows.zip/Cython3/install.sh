python3.6 setup.py build_ext --inplace
