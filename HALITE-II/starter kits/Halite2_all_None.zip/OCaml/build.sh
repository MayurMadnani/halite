#!/bin/bash
ocamlbuild -lib unix MyBot.native
