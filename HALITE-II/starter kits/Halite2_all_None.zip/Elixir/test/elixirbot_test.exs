defmodule ElixirbotTest do
  use ExUnit.Case
  doctest Elixirbot

end
