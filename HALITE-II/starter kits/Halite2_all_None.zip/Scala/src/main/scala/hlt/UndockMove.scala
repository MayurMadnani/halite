package hlt

class UndockMove(override val ship: Ship) extends Move(Move.Undock, ship)
