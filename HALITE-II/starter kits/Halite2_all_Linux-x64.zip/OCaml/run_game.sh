#!/bin/sh

./halite -d "240 160" "./MyBot.native" "./MyBot.native"
