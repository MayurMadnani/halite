#!/bin/sh

./halite -d "240 160" "julia MyBot.jl" "julia MyBot.jl"
