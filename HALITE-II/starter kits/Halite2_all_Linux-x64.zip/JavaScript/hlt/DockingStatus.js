module.exports = {
    UNDOCKED: 0,
    DOCKING: 1,
    DOCKED: 2,
    UNDOCKING: 3
};
