defmodule Elixirbot.UtilTest do
  use ExUnit.Case
  doctest Elixirbot.Util

end
