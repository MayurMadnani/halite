#!/bin/sh

./halite -d "240 160" "dart MyBot.dart" "dart MyBot.dart"
