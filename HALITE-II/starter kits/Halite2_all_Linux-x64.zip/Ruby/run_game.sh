#!/bin/sh

./halite -d "240 160" "ruby MyBot.rb" "ruby MyBot.rb"
